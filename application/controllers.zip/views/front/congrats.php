<h2>Select Courses</h2>
<div class="seperator"></div>
You have successfully completed all the lesson of the course, <b>'<?php echo $cat;?>'</b>.
