<h2>Success</h2>
<div class="seperator"></div>
<p>You’ve successfully registered to Training Management system. 
	Thanks for registering with us.
        You can enroll now and then make the payment or book an appointment for payments.
	<a href="<?php echo base_url();?>trainee" class="btn btn-info">Enroll and Pay</a>
        
	To find out what we offer, <a href="<?php echo base_url();?>appointmment" class="btn btn-info">Book an Appointment</a>
      

Thank you!
</p>