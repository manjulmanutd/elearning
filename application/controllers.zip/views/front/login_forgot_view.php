<h2>Success</h2>
<div class="seperator"></div>
<p>Your login details have been emailed. Please check your email.</p>
<a href="javascript:history.go(-2)" class="btn btn-success">Go to home page</a>