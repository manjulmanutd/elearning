<div class="h_left"><h2>Site Configuration</h2></div>
<div class="seperator"></div>
<ul class="cates">
<h3>Choose your option.</h3>
<a href="site_configuration/login_setting" class="btn btn-inverse">Login Settings</a>
<a href="site_configuration/site_setting" class="btn btn-info">Site Settings</a>
</ul>