<div class="h_left"><h2>Time Slot Configuration</h2></div>
<div class="seperator"></div>
<ul class="cates">
<h3>Choose your option.</h3>
<a href="<?php echo base_url();?>timeslot/list_appointment_timeslots" class="btn btn-inverse">Appointment Time Slot</a>
<a href="<?php echo base_url();?>timeslot/list_trainer_timeslots" class="btn btn-info">Trainer Time Slot</a>
</ul>