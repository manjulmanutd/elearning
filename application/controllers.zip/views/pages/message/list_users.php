<?php foreach($usersByType as $user):?>

   <option value="<?php echo $user->id; ?>"><?php echo $course->user_name;?></option>
<?php endforeach; ?>

  