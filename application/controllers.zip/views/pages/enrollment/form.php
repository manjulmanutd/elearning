<h2>Enroll Now</h2>
<hr />
<form action="" method="post">
<label>Sur Name</label><input type="text" name="sur_name" />
<label>First Name</label><input type="text" name="name" />
<label>Gender</label>Male:<input type="radio" name="gender" value="male" />&nbsp;&nbsp;&nbsp;&nbsp;Female:<input type="radio" name="gender" value="female"/>
<label>Address</label><textarea name="address"></textarea> 
<label>Post Code</label><input type="text" name="post_code" />
<label>Date Of Birth</label><input type="text" name="dob" />
<label>NI No.</label><input type="text" name="ni_no" />
<label>Mobile Tel.</label><input type="text" name="mob_no" />
<label>Alternate Tel.</label><input type="text" name="altr_no" />
<hr />
<h3>Emegerncy Contact Person</h3>
<hr />
<label>Name</label><input type="text" name="contact_name" />
<label>Telephone</label><input type="text" name="contact_no" />
<hr />
<h3>ABOUT WORK EXPERIENCE</h3>
<hr />
<label>When would you like to start:</label><input type="text" name="start_date" />
<label>Which area(s) would you like to gain work experience in?</label>
<input type="radio" name="experience" />  Accounts Assistant/Bookkeeper/ Accounts payable & receivable clerk - {for 1-2 Months} £ 600 <br />
<input type="radio" name="experience" />  Sage Line 50 Training – { for 3 days } £300 <br />
<input type="radio" name="experience" />  Financial Accountant: Financial Accounting & Payroll Accounting together – {for 2 - 4 Months} £1,200 <br />
<input type="radio" name="experience" />  Professional Accountant: Financial, Management, Payroll & Tax Accounting – {for 3-6 Months} £ 2,200 <br />
<input type="radio" name="experience" />  Management Accountant: Budgeting, Corporate Reporting, Breakeven analysis - {for 1 Month} £ 960 <br />
<input type="radio" name="experience" />  Tax Accountant – Tax returns, Capital Allowances, UK VAT accounting, - {for 1 Month} £500 <br />
<input type="radio" name="experience" />  Payroll Accounting - {for 1 Month} £ 600 <br />
<input type="radio" name="experience" />  Using Excel competently (Specific for Accountants) – {for 4 days} £ 480

<label>How would You like To Pay.</label>
Cash<input type="radio" value="cash" name="pay" /> &nbsp;&nbsp;&nbsp;&nbsp; Card<input type="radio" value="card" name="pay" />
<hr />
<h3>CAREER PROGRESSION & RECRUITMENT WITH TD&A</h3>
<hr />
<label>As a TD&A trainee, you are entitled to a free CV Session, Job interview tips and listing on our financial recruitment 
database. Here are some few things we would to know from you in advance:</label>
<label>*  What is your ideal accountancy job?</label><input type="text" value=""  />
<label>*  Which industry would you like to work in?</label><input type="text" value=""  />
<label>*  What is your ideal salary requirement?</label><input type="text" value=""  />
<label>*  How many jobs have you applied for in the past month?</label><input type="text" value=""  />
<label>*  What job are you doing at the moment?</label><input type="text" value=""  /><br />





<input type="submit" name="submit" value="Submit" class="btn btn-primary" />
</form>