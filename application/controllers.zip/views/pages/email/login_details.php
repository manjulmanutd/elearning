<p>Hello <?php echo $first_name;?>,</p>
 <p>&nbsp;&nbsp;&nbsp;&nbsp;Here are the login details.</p>
 <p>Username: <?php echo $username;?></p>
 <p>Password: <?php echo $password;?></p>
<br/>
 <p>Thanks</p>